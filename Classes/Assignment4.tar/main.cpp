/******************************************************************************
# Author:           Zakeriya Muhumed # Assignment:       A04 (CS162)
# Date:             November 18, 2022
# Description:      Classes and pointer with assigment 3 
# Input:            This program takes in the number of media post, the author, website, title, text, #likes, dislikes.  
# Output:           With the differnet user interfaces, this program can read in new items and store it in the array or display all the data with the largest number of likes  
# Sources:          Assignment 3,4 instruction
#******************************************************************************/
#include "a04.h"

//Main function
int main(){
    Social tweet;
    int choice = 0;
    while(choice != 3){
        menu();
        cin >> choice;
        cin.ignore();
        while((choice < 1 && choice > 3) || (!cin)){
            menu();
            cin>> choice;
            cin.ignore();
        }
        switch(choice){
            case 1:
                tweet.input();
                break;
            case 2:
                cout << endl;
                tweet.display_all();
                break;
        }
    }	
    return 0;
}

