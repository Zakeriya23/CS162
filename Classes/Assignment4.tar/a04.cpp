#include "a04.h"
//This is the constructor function.
Social:: Social(){
    cout <<"\nHow many media post would you like to insert ?" << endl;
    cout << "\t-->";
    cin >> size;
    Elon = new media[size];
    count =0;
    greatest =0;
    index =0;
}
//This is the Destructor function
Social :: ~Social(){
    if(NULL != Elon)
        delete []Elon;
    Elon = nullptr;
}
//Name: void menu();
//Description: Print the menu
//input params: None 
//output: None
//return: none 
void menu(){ 
    cout<< "\nPick 1-3 options" << endl;
    cout <<"\t1) Input media post"<< endl;
    cout <<"\t2) Display all" << endl;
    cout <<"\t3) Quit" << endl;
    cout <<"\n\t\t--->";
}
//Name:          void input();
//Description:   This function gets called on the read function until the user stops or the size of array is done.
//input params:  none
//ouput:        none
//return:       none
void Social:: input(){
    char yes = 'y';
    while(tolower (yes) == 'y' && count < size){
        Elon[count].read();
        count ++;
        cout << "\n\t\tWould you like to enter more?" << endl << "\t\t--> ";
        cin >> yes;
        cin.ignore(100,'\n'); 
    }
}
//Name:          void read();
//Description:   When this function is called on, this function get the user input.
//input params:  none
//ouput:        none
//return:       none
void media:: read(){
    cout << "Enter Author:"<<endl << "\t--->";
    cin.get(author,MAX, '\n');	
    cin.ignore(100,'\n');

    cout << "Enter Title:"<< endl<< "\t--->";
    cin.get(title,MAX,'\n');
    cin.ignore(100,'\n');

    cout << "Enter Website:"<< endl<< "\t--->";
    cin.get(web,MAX,'\n');
    cin.ignore(100,'\n');

    cout << "Enter Text:"<< endl<< "\t--->";
    cin.get(text,MAX,'\n');
    cin.ignore(100,'\n');

    cout << "Enter Likes:"<< endl<< "\t--->";
    cin >> likes;
    cin.ignore(100,'\n');
    while(!cin || likes < 0){
        cin.clear();
        cin.ignore(100,'\n');
        cout <<"\tPlease enter a number: ";
        cin>> likes;	
    }

    cout << "Enter Dislike:"<< endl<< "\t--->";
    cin >> dislikes;
    cin.ignore(100,'\n');
    while(!cin || dislikes < 0){
        cin.clear();
        cin.ignore(100,'\n');
        cout <<"\tPlease enter a number: ";
        cin>> dislikes;
    }

}
//Name:        display_all() ;
//Description:   This function call on the display function.
//input params:  none
//ouput:        media information
//return:       none
void Social :: display_all(){
    if(count !=0){
        for(int i =0; i < count; ++i){
            cout << "Media Post "<< i+1 << ":" << endl;
            Elon[i].display();
            cout << endl;
        }
        for(int j=0; j< count; ++j){
            if(Elon[j].likes > greatest){
                greatest = Elon[j].likes;
                index =j;
            }
        }
        cout << "\nThe greatest number of likes was:" << greatest << endl;
        cout << "Media post with greatest number of likes:" << endl;
        Elon[index].display();
        cout << endl;
    }
    else cout << "\tNo media post to display, Please store first!!" <<endl;
}
//Name:        display() ;
//Description:   This function print the information
//input params:  none
//ouput:        media information
//return:       none
void media::display(){
    cout <<"\tAuthor: " <<  author <<endl;
    cout << "\tTitle: " << title<< endl;
    cout << "\tWebsite: " << web<< endl;
    cout << "\tText: " << text << endl; 
    cout <<"\tLikes: "<< likes << endl;
    cout <<"\tDislikes: " << dislikes << endl;
}
