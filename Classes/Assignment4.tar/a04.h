#pragma once
#include <fstream>
#include <iostream>
#include <cstring>
#include <cctype>
#include<string>
#include <iomanip>
using namespace std;

//const int for the size of the struct arrays
const int MAX = 101;

//struct for the user and all the important information
void menu();
struct media{
    void read();
    void display();
    char author[MAX];
    char title[MAX];
    char web[MAX];
    char text[MAX];
    int likes;
    int dislikes;
};
class Social{
    public:
        Social();	
        ~Social(); 
        void input();
        void display_all();
    private:	
        media *Elon;
        int size;
        int count;
        int greatest;
        int index;
};
